package gr.kallipos.cryptography.chap03.hashes.testing;

import gr.kallipos.cryptography.chap03.hashes.alg.BCrypt;
import gr.kallipos.cryptography.chap03.hashes.alg.scrypt.crypto.SCryptUtil;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class TestHashAlgs {

	/**
	 * @param args
	 * @throws NoSuchAlgorithmException 
	 */
	public static void main(String[] args) throws NoSuchAlgorithmException {
		String message = "Cryptography";
		String salt = "2022";
		System.out.println("Message: "+message);
		
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(message.getBytes());
		byte[] digest = md.digest();
		System.out.println("MD5: "+toHexString(digest));
		
		MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
		sha1.update(message.getBytes());
		digest = sha1.digest();
		System.out.println("SHA-1: "+toHexString(digest));
		
		MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
		sha256.update(message.getBytes());
		digest = sha256.digest();
		System.out.println("SHA-256: "+toHexString(digest));
		
		MessageDigest sha256salted = MessageDigest.getInstance("SHA-256");
		sha256salted.update(salt.getBytes());
		sha256salted.update(message.getBytes());
		digest = sha256salted.digest();
		System.out.println("SHA-256 with salt("+salt+"): "+toHexString(digest));
		
		MessageDigest sha384 = MessageDigest.getInstance("SHA-384");
		sha384.update(message.getBytes());
		digest = sha384.digest();
		System.out.println("SHA-384: "+toHexString(digest));
		
		MessageDigest sha512 = MessageDigest.getInstance("SHA-512");
		sha512.update(message.getBytes());
		digest = sha512.digest();
		System.out.println("SHA-512: "+toHexString(digest));
		
		String generatedSecuredPasswordHashBCrypt = BCrypt.hashpw(message, BCrypt.gensalt(12));
        System.out.println("BCrypt hash: "+generatedSecuredPasswordHashBCrypt);
        boolean matched = BCrypt.checkpw(message, generatedSecuredPasswordHashBCrypt);
        System.out.println("BCrypt validation: "+matched);
        
        String generatedSecuredPasswordHashSCrypt = SCryptUtil.scrypt(message, 16, 16, 16);
        System.out.println("SCrypt hash: "+generatedSecuredPasswordHashSCrypt);
        matched = SCryptUtil.check(message, generatedSecuredPasswordHashSCrypt);
        System.out.println("SCrypt validation: "+matched);

	}
	
	public static String toHexString(byte[] digest){
		StringBuffer hexString = new StringBuffer();
		for (byte b : digest) {
			hexString.append(String.format("%02x", b & 0xff));
		}
		return hexString.toString();
	}

}
