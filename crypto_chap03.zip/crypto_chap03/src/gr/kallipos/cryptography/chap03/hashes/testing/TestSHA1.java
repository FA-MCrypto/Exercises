package gr.kallipos.cryptography.chap03.hashes.testing;

import gr.kallipos.cryptography.chap03.hashes.alg.SHA1;

public class TestSHA1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String message = "Cryptography";

			SHA1 s = new SHA1();
			s.init();
			s.update(message.getBytes());
			s.finish();
			
			System.out.println(s.digout());
	}

}
