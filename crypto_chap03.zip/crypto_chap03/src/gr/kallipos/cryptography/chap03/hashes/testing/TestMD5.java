package gr.kallipos.cryptography.chap03.hashes.testing;

import gr.kallipos.cryptography.chap03.hashes.alg.MD5;

public class TestMD5 {

    public static void main (String[] args){
    	String message = "Cryptography";
    	
    	MD5 md5 = new MD5();
    	md5.update(message);
    	System.out.println(md5.getHashString());
    }

}
