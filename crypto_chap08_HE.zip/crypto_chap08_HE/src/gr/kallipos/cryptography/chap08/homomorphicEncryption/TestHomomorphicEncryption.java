package gr.kallipos.cryptography.chap08.homomorphicEncryption;

import gr.kallipos.cryptography.chap08.asymmetric.elgamal.CipherTextElGamal;
import gr.kallipos.cryptography.chap08.asymmetric.elgamal.ElgamalKeyPair;
import gr.kallipos.cryptography.chap08.asymmetric.paillier.PaillierKeyPair;
import gr.kallipos.cryptography.chap08.asymmetric.rsa.RSAKeyPair;

import java.math.BigInteger;

public class TestHomomorphicEncryption {
	
	public static void main(String[] args) {
		RSAKeyPair pkpRSA = new RSAKeyPair(1024);
		//ElgamalKeyPair pkpElGamal = new ElgamalKeyPair(1024); // very slow
		ElgamalKeyPair pkpElGamal = new ElgamalKeyPair(ElgamalKeyPair.p1024,ElgamalKeyPair.g1024); // fast
		PaillierKeyPair pkpPaillier = new PaillierKeyPair(1024);

		/* instantiating two plaintext msgs*/
		BigInteger m1 = BigInteger.valueOf(5);
		BigInteger m2 = BigInteger.valueOf(3);
		
		/* encryption RSA*/
		BigInteger em1RSA = pkpRSA.PublicKey.Encryption(m1);
		BigInteger em2RSA = pkpRSA.PublicKey.Encryption(m2);
		System.out.println("RSA c1 -> \n"+em1RSA);
		System.out.println("RSA c2 -> \n"+em2RSA);
		
		BigInteger emmRSA = em1RSA.multiply(em2RSA).mod(pkpRSA.PublicKey.n);
		System.out.println("RSA c1*c2 -> \n"+emmRSA);
		System.out.println("RSA decrypted multiplication: " + pkpRSA.PrivateKey.Decryption(emmRSA));	
		System.out.println();
		
		/* encryption ElGamal*/
		CipherTextElGamal em1ElGamal = pkpElGamal.PublicKey.Encryption(m1);
		CipherTextElGamal em2ElGamal = pkpElGamal.PublicKey.Encryption(m2);
		System.out.println("ElGamal c1 -> \n"+em1ElGamal);
		System.out.println("ElGamal c2 -> \n"+em2ElGamal);
		
		CipherTextElGamal emmElGamal = new CipherTextElGamal(em1ElGamal.delta.multiply(em2ElGamal.delta).mod(pkpElGamal.PublicKey.p), em1ElGamal.gamma.multiply(em2ElGamal.gamma).mod(pkpElGamal.PublicKey.p));
		System.out.println("ElGamal c1*c2 -> \n"+emmElGamal);
		System.out.println("ElGamal decrypted multiplication: " + pkpElGamal.PrivateKey.Decryption(emmElGamal));
		System.out.println();
		
		/* encryption Paillier*/
		BigInteger em1Paillier = pkpPaillier.PublicKey.Encryption(m1);
		BigInteger em2Paillier = pkpPaillier.PublicKey.Encryption(m2);
		System.out.println("Paillier c1 -> \n"+em1Paillier);
		System.out.println("Paillier c2 -> \n"+em2Paillier);
		
		BigInteger emmPaillier = em1Paillier.multiply(em2Paillier).mod(pkpPaillier.PublicKey.nsquare);
		System.out.println("Paillier c1*c2 -> \n"+emmPaillier);
		System.out.println("Paillier decrypted multiplication: " + pkpPaillier.PrivateKey.Decryption(emmPaillier));	
		System.out.println();
	}

}
