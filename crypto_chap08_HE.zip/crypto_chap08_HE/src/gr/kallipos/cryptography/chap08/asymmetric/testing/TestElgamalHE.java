package gr.kallipos.cryptography.chap08.asymmetric.testing;

import gr.kallipos.cryptography.chap08.asymmetric.elgamal.CipherTextElGamal;
import gr.kallipos.cryptography.chap08.asymmetric.elgamal.ElgamalKeyPair;
import gr.kallipos.cryptography.chap08.asymmetric.paillier.PaillierKeyPair;

import java.math.BigInteger;

public class TestElgamalHE {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//ElgamalKeyPair pkp = new ElgamalKeyPair(1024); // very slow
		ElgamalKeyPair pkp = new ElgamalKeyPair(ElgamalKeyPair.p1024,ElgamalKeyPair.g1024); // fast

		/* instantiating two plaintext msgs*/
		BigInteger m1 = BigInteger.valueOf(5);
		BigInteger m2 = BigInteger.valueOf(3);
		/* encryption*/
		CipherTextElGamal em1 = pkp.PublicKey.Encryption(m1);
		CipherTextElGamal em2 = pkp.PublicKey.Encryption(m2);
		System.out.println("c1 -> \n"+em1);
		System.out.println("c2 -> \n"+em2);
		
		CipherTextElGamal he = new CipherTextElGamal(em1.delta.multiply(em2.delta).mod(pkp.PublicKey.p), em1.gamma.multiply(em2.gamma).mod(pkp.PublicKey.p));
		
		System.out.println("c1*c2 -> \n" + he);
		System.out.println("decrypted c2: " + pkp.PrivateKey.Decryption(he));
	}

}
