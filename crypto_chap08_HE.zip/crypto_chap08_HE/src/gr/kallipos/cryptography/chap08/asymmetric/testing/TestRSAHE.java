package gr.kallipos.cryptography.chap08.asymmetric.testing;

import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import gr.kallipos.cryptography.chap08.asymmetric.rsa.PaddedRSA_PKCS;
import gr.kallipos.cryptography.chap08.asymmetric.rsa.RSAKeyPair;

public class TestRSAHE {

	/**
	 * @param args
	 * @throws NoSuchAlgorithmException 
	 * @throws BadPaddingException 
	 * @throws IllegalBlockSizeException 
	 * @throws NoSuchPaddingException 
	 * @throws InvalidKeyException 
	 */
	public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
		RSAKeyPair pkp = new RSAKeyPair(1024);

		/* instantiating two plaintext msgs*/
		BigInteger m1 = BigInteger.valueOf(5);
		BigInteger m2 = BigInteger.valueOf(3);
		/* encryption*/
		BigInteger em1 = pkp.PublicKey.Encryption(m1);
		BigInteger em2 = pkp.PublicKey.Encryption(m2);
		
		System.out.println("c1 = "+em1);
		System.out.println("c2 = "+em2);

		BigInteger he = em1.multiply(em2).mod(pkp.PublicKey.n);

		System.out.println("c1*c2: " + he);
		System.out.println("decrypted c1*c2: " + pkp.PrivateKey.Decryption(he));
	}

}
