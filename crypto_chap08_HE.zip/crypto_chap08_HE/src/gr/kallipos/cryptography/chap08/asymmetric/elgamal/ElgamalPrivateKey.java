package gr.kallipos.cryptography.chap08.asymmetric.elgamal;

import java.io.Serializable;
import java.math.BigInteger;

public class ElgamalPrivateKey implements Serializable {
	
	/**
	 * number of bits of modulus
	 */
	public int bitLength;
	/**
	 * p is a large prime.
	 */
	public BigInteger p;
	/**
	 * 'a' private key
	 */
	public BigInteger a;
	

	public ElgamalPrivateKey() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Decrypts ciphertext c.
	 * @param c ciphertext as a CipherTextElGamal
	 * @return plaintext as a BigInteger
	 */
	public BigInteger Decryption(CipherTextElGamal c) {
		
		BigInteger biGamma = c.getGAMMA();
		BigInteger biDelta = c.getDELTA();
		
		return biGamma.modPow(p.subtract(BigInteger.ONE).subtract(a), p).multiply(biDelta).mod(p);
	}
}
