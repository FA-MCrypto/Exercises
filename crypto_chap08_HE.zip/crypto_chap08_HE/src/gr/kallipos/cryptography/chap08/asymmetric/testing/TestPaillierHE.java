package gr.kallipos.cryptography.chap08.asymmetric.testing;

import java.math.BigInteger;

import gr.kallipos.cryptography.chap08.asymmetric.paillier.PaillierKeyPair;

public class TestPaillierHE {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		PaillierKeyPair pkp = new PaillierKeyPair(1024);

		/* instantiating two plaintext msgs*/
		BigInteger m1 = BigInteger.valueOf(5);
		BigInteger m2 = BigInteger.valueOf(3);
		/* encryption*/
		BigInteger em1 = pkp.PublicKey.Encryption(m1);
		BigInteger em2 = pkp.PublicKey.Encryption(m2);
		
		System.out.println("c1 = "+em1);
		System.out.println("c2 = "+em2);
		
		BigInteger he = em1.multiply(em2).mod(pkp.PublicKey.nsquare);
		
		System.out.println("c1*c2: " + he);
		System.out.println("decrypted c1*c2: " + pkp.PrivateKey.Decryption(he));
	}

}
