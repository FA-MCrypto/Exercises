package gr.kallipos.cryptography.chap08.asymmetric.paillier;

import java.io.Serializable;
import java.math.BigInteger;
import java.security.SecureRandom;

public class PaillierPublicKey implements Serializable {

	/**
	 * number of bits of modulus
	 */
	public int bitLength;
	/**
	 * n = p*q, where p and q are two large primes.
	 */
	public BigInteger n;
	/**
	 * nsquare = n*n
	 */
	public BigInteger nsquare;
	/**
	 * a random integer in Z*_{n^2} where gcd (L(g^lambda mod n^2), n) = 1.
	 */
	public BigInteger g;
	
	public PaillierPublicKey() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Encrypts plaintext m. ciphertext c = g^m * r^n mod n^2. This function automatically generates random input r (to help with encryption).
	 * @param m plaintext as a BigInteger
	 * @return ciphertext as a BigInteger
	 */
	public BigInteger Encryption(BigInteger m) {
		BigInteger r = new BigInteger(bitLength, new SecureRandom());
		return g.modPow(m, nsquare).multiply(r.modPow(n, nsquare)).mod(nsquare);
	}
	
	public boolean equals(Object arg0){
		PaillierPublicKey pk = (PaillierPublicKey)arg0;
		if(this.bitLength == pk.bitLength && this.n.equals(pk.n) && this.nsquare.equals(pk.nsquare) && this.g.equals(pk.g)) return true;
		else return false;
	}

}
