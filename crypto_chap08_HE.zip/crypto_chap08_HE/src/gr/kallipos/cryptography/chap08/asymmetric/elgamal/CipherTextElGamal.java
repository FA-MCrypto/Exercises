package gr.kallipos.cryptography.chap08.asymmetric.elgamal;

import java.io.Serializable;
import java.math.BigInteger;

public class CipherTextElGamal implements Serializable,Cloneable {

	public BigInteger delta;
	public BigInteger gamma;

	public CipherTextElGamal() {
		delta = null;
		gamma = null;
	}

	public CipherTextElGamal(BigInteger delta, BigInteger gamma) {
		this.delta = delta;
		this.gamma = gamma;
	}

	public BigInteger getDELTA() {
		return delta;
	}

	public BigInteger getGAMMA() {
		return gamma;
	}

	public void setDELTA(BigInteger delta) {
		this.delta = delta;
	}

	public void setGAMMA(BigInteger gamma) {
		this.gamma = gamma;
	}

	public String toString() {
		return "Delta= " + delta + "\nGamma= " + gamma;
	}
	
    public Object clone() {
    	CipherTextElGamal cte = null;
        try {
            cte = (CipherTextElGamal)super.clone();
        }
        catch (CloneNotSupportedException e) {
            // This should never happen
            throw new InternalError(e.toString());
        }
        cte.delta = new BigInteger(delta.toByteArray().clone());
        cte.gamma = new BigInteger(gamma.toByteArray().clone());
        return cte;
    }
}
