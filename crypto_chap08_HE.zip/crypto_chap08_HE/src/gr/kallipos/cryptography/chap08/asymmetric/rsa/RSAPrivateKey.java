package gr.kallipos.cryptography.chap08.asymmetric.rsa;

import java.io.Serializable;
import java.math.BigInteger;

public class RSAPrivateKey implements Serializable {
	
	/**
	 * number of bits of modulus
	 */
	public int bitLength;
	/**
	 * n = p*q, where p and q are two large primes.
	 */
	public BigInteger n;
	/**
	 * d private key
	 */
	public BigInteger d;
	

	public RSAPrivateKey() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Decrypts ciphertext c
	 * @param c ciphertext as a BigInteger
	 * @return plaintext as a BigInteger
	 */
	public BigInteger Decryption(BigInteger c) {
		return c.modPow(d, n);
	}
}
