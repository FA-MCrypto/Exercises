package gr.kallipos.cryptography.chap08.asymmetric.rsa;

import java.io.Serializable;
import java.math.BigInteger;
import java.security.SecureRandom;

public class RSAPublicKey implements Serializable {

	/**
	 * number of bits of modulus
	 */
	public int bitLength;
	/**
	 * n = p*q, where p and q are two large primes.
	 */
	public BigInteger n;
	/**
	 * a random integer e.
	 */
	public BigInteger e;
	
	public RSAPublicKey() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Encrypts plaintext m.
	 * @param m plaintext as a BigInteger
	 * @return ciphertext as a BigInteger
	 */
	public BigInteger Encryption(BigInteger m) {
		return m.modPow(e, n);
	}
	
	public boolean equals(Object arg0){
		RSAPublicKey pk = (RSAPublicKey)arg0;
		if(this.bitLength == pk.bitLength && this.n.equals(pk.n) && this.e.equals(pk.e)) return true;
		else return false;
	}

}
