package gr.kallipos.cryptography.chap02.asymmetric.paillier;

import java.io.Serializable;
import java.math.BigInteger;

public class PaillierPrivateKey implements Serializable {
	
	/**
	 * number of bits of modulus
	 */
	public int bitLength;
	/**
	 * n = p*q, where p and q are two large primes.
	 */
	public BigInteger n;
	/**
	 * nsquare = n*n
	 */
	public BigInteger nsquare;
	/**
	 * p and q are two large primes.
	 * lambda = lcm(p-1, q-1) = (p-1)*(q-1)/gcd(p-1, q-1).
	 */
	public BigInteger lambda;
	/**
	 * u = (L(g^lambda mod n^2))^(-1) mod n
	 */
	public BigInteger u;
	

	public PaillierPrivateKey() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Decrypts ciphertext c. plaintext m = L(c^lambda mod n^2) * u mod n, where u = (L(g^lambda mod n^2))^(-1) mod n.
	 * @param c ciphertext as a BigInteger
	 * @return plaintext as a BigInteger
	 */
	public BigInteger Decryption(BigInteger c) {
		return c.modPow(lambda, nsquare).subtract(BigInteger.ONE).divide(n).multiply(u).mod(n);
	}
}
