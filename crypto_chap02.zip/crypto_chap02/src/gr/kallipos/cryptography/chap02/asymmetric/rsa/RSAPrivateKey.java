package gr.kallipos.cryptography.chap02.asymmetric.rsa;

import java.io.Serializable;
import java.math.BigInteger;

public class RSAPrivateKey implements Serializable {
	
	/**
	 * number of bits of modulus
	 */
	public int bitLength;
	/**
	 * n = p*q, where p and q are two large primes.
	 */
	public BigInteger n;
	/**
	 * d private key
	 */
	public BigInteger d;
	

	public RSAPrivateKey() {

	}

	public BigInteger Decryption(BigInteger c) {
		return c.modPow(d, n);
	}
	
	public BigInteger Sign(BigInteger m) {
		return m.modPow(d, n);
	}
}
