package gr.kallipos.cryptography.chap02.asymmetric.elgamal;

import java.io.Serializable;
import java.math.BigInteger;

public class SignatureElGamal implements Serializable,Cloneable {

	public BigInteger r;
	public BigInteger s;

	public SignatureElGamal() {
		r = null;
		s = null;
	}

	public SignatureElGamal(BigInteger r, BigInteger s) {
		this.r = r;
		this.s = s;
	}

	public BigInteger getR() {
		return r;
	}

	public BigInteger getS() {
		return s;
	}

	public void setR(BigInteger r) {
		this.r = r;
	}

	public void setS(BigInteger s) {
		this.s = s;
	}

	public String toString() {
		return "R= " + r + "\nS= " + s;
	}
	
    public Object clone() {
    	SignatureElGamal cte = null;
        try {
            cte = (SignatureElGamal)super.clone();
        }
        catch (CloneNotSupportedException e) {
            // This should never happen
            throw new InternalError(e.toString());
        }
        cte.r = new BigInteger(r.toByteArray().clone());
        cte.s = new BigInteger(s.toByteArray().clone());
        return cte;
    }
}
