package gr.kallipos.cryptography.chap02.asymmetric.elgamal;

import java.io.Serializable;
import java.math.BigInteger;
import java.security.SecureRandom;

public class ElgamalPublicKey implements Serializable {

	private static final BigInteger TWO = BigInteger.valueOf(2);
	/**
	 * number of bits of modulus
	 */
	public int bitLength;
	/**
	 * p is a large prime.
	 */
	public BigInteger p;
	/**
	 * generator g.
	 */
	public BigInteger g;
	/**
	 * y = g^a mod p
	 */
	public BigInteger y;
	
	public ElgamalPublicKey() {
		
	}

	public CipherTextElGamal Encryption(BigInteger m) {
		SecureRandom random = new SecureRandom();
		BigInteger r = new BigInteger(bitLength, random);

		while (r.equals(BigInteger.ZERO) || (r.compareTo(p.subtract(TWO)) > 0)) {
			r = new BigInteger(bitLength, random);
		}
		return new CipherTextElGamal(m.multiply(y.modPow(r, p)).mod(p), g.modPow(r, p));
	}
	
	public boolean VerifySign(BigInteger m, SignatureElGamal sign) {
		
		if((y.modPow(sign.r, p).multiply(sign.r.modPow(sign.s, p)).mod(p)).equals(g.modPow(m, p))){
			return true;
		}else{
			return false;
		}
	}
	
	public boolean equals(Object arg0){
		ElgamalPublicKey pk = (ElgamalPublicKey)arg0;
		if(this.bitLength == pk.bitLength && this.p.equals(pk.p) && this.g.equals(pk.g) && this.y.equals(pk.y)) return true;
		else return false;
	}

}
