package gr.kallipos.cryptography.chap02.asymmetric.rsa;

import java.io.Serializable;
import java.math.BigInteger;

public class RSAPublicKey implements Serializable {

	/**
	 * number of bits of modulus
	 */
	public int bitLength;
	/**
	 * n = p*q, where p and q are two large primes.
	 */
	public BigInteger n;
	/**
	 * a random integer e.
	 */
	public BigInteger e;
	
	public RSAPublicKey() {

	}

	public BigInteger Encryption(BigInteger m) {
		return m.modPow(e, n);
	}
	
	public boolean VerifySign(BigInteger m, BigInteger s) {
		
		if((s.modPow(e, n)).equals(m)){
			return true;
		}else{
			return false;
		}
	}
	
	public boolean equals(Object arg0){
		RSAPublicKey pk = (RSAPublicKey)arg0;
		if(this.bitLength == pk.bitLength && this.n.equals(pk.n) && this.e.equals(pk.e)) return true;
		else return false;
	}

}
