package gr.kallipos.cryptography.chap02.asymmetric.testing.encryption;

import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;

import gr.kallipos.cryptography.chap02.asymmetric.rsa.PaddedRSA_PKCS;
import gr.kallipos.cryptography.chap02.asymmetric.rsa.RSAKeyPair;

public class TestRSAEncr {

	/**
	 * @param args
	 * @throws NoSuchAlgorithmException 
	 */
	public static void main(String[] args) throws Exception {
		RSAKeyPair pkp = new RSAKeyPair(1024);
		PaddedRSA_PKCS padded_pkp = new PaddedRSA_PKCS(1024);

		/* instantiating two plaintext msgs*/
		BigInteger m1 = BigInteger.valueOf(5);
		BigInteger m2 = BigInteger.valueOf(3);
		BigInteger m3 = BigInteger.valueOf(8);
		
		/* encryption*/
		BigInteger em1 = pkp.PublicKey.Encryption(m1);
		BigInteger em2 = pkp.PublicKey.Encryption(m2);
		
		/* encryption with PaddedRSA*/
		BigInteger padded_em31 = padded_pkp.Encryption(m3);
		BigInteger padded_em32 = padded_pkp.Encryption(m3);
		
		System.out.println("c1 = "+em1);
		System.out.println("c2 = "+em2);
		
		System.out.println("c3.1 (with Padded RSA) = "+padded_em31);
		System.out.println("c3.2 (with Padded RSA) = "+padded_em32);
		
		System.out.println("decrypted c1: " + pkp.PrivateKey.Decryption(em1));
		System.out.println("decrypted c2: " + pkp.PrivateKey.Decryption(em2));
		
		System.out.println("decrypted c3.1 (with Padded RSA): " + padded_pkp.Decryption(padded_em31));
		System.out.println("decrypted c3.2 (with Padded RSA): " + padded_pkp.Decryption(padded_em32));
	}

}
