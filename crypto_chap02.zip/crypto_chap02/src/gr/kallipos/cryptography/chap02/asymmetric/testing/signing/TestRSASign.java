package gr.kallipos.cryptography.chap02.asymmetric.testing.signing;

import java.math.BigInteger;

import gr.kallipos.cryptography.chap02.asymmetric.rsa.RSAKeyPair;

public class TestRSASign {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		RSAKeyPair pkp = new RSAKeyPair(1024);

		/* instantiating two plaintext msgs*/
		BigInteger m1 = BigInteger.valueOf(5);
		BigInteger m2 = BigInteger.valueOf(3);

		/* sign */
		BigInteger s1 = pkp.PrivateKey.Sign(m1);
		BigInteger s2 = pkp.PrivateKey.Sign(m2);
	
		System.out.println("Sign1 = "+s1);
		System.out.println("Sign2 = "+s2);
		
		System.out.println("Verify Sign1: " + pkp.PublicKey.VerifySign(m1, s1));
		System.out.println("Verify Sign2: " + pkp.PublicKey.VerifySign(m2, s2));
	}

}
