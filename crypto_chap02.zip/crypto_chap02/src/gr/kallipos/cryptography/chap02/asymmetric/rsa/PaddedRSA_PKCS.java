package gr.kallipos.cryptography.chap02.asymmetric.rsa;

import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class PaddedRSA_PKCS {

public PublicKey PublicKey;
public PrivateKey PrivateKey;

public PaddedRSA_PKCS(int bitLengthVal) throws NoSuchAlgorithmException
{
	generateKeys(bitLengthVal);
}

private void generateKeys(int bits) throws NoSuchAlgorithmException{
    KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
    kpg.initialize(bits);
    KeyPair kp = kpg.genKeyPair();

    PublicKey = kp.getPublic();
    PrivateKey = kp.getPrivate();
}


public BigInteger Encryption(BigInteger plain) throws NoSuchAlgorithmException,
        NoSuchPaddingException, InvalidKeyException,
        IllegalBlockSizeException, BadPaddingException {

	BigInteger encrypted;
    byte[] encryptedBytes;      

    Cipher cipher = Cipher.getInstance("RSA");
    cipher.init(Cipher.ENCRYPT_MODE, PublicKey);
    encryptedBytes = cipher.doFinal(plain.toByteArray());

    encrypted = new BigInteger(encryptedBytes);
    return encrypted;

}

public BigInteger Decryption(BigInteger ciphertext) throws NoSuchAlgorithmException,
        NoSuchPaddingException, InvalidKeyException,
        IllegalBlockSizeException, BadPaddingException {

    byte[] decryptedBytes;
    BigInteger decrypted;

    Cipher cipher = Cipher.getInstance("RSA");
    cipher.init(Cipher.DECRYPT_MODE, PrivateKey);
    decryptedBytes = cipher.doFinal(ciphertext.toByteArray());
    decrypted = new BigInteger(decryptedBytes);
    return decrypted;

}

}