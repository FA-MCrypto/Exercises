package gr.kallipos.cryptography.chap02.asymmetric.testing.encryption;

import gr.kallipos.cryptography.chap02.asymmetric.elgamal.CipherTextElGamal;
import gr.kallipos.cryptography.chap02.asymmetric.elgamal.ElgamalKeyPair;

import java.math.BigInteger;

public class TestElgamalEncr {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//ElgamalKeyPair pkp = new ElgamalKeyPair(1024); // very slow
		ElgamalKeyPair pkp = new ElgamalKeyPair(ElgamalKeyPair.p1024,ElgamalKeyPair.g1024); // fast

		/* instantiating two plaintext msgs*/
		BigInteger m1 = BigInteger.valueOf(5);
		BigInteger m2 = BigInteger.valueOf(3);
		
		/* encryption*/
		CipherTextElGamal em1 = pkp.PublicKey.Encryption(m1);
		CipherTextElGamal em2 = pkp.PublicKey.Encryption(m2);
		
		System.out.println("c1 -> \n"+em1);
		System.out.println("c2 -> \n"+em2);
		
		System.out.println("decrypted c1: " + pkp.PrivateKey.Decryption(em1));
		System.out.println("decrypted c2: " + pkp.PrivateKey.Decryption(em2));
	}

}
