package gr.kallipos.cryptography.chap02.asymmetric.elgamal;

import java.io.Serializable;
import java.math.BigInteger;
import java.security.SecureRandom;

public class ElgamalPrivateKey implements Serializable {
	
	/**
	 * number of bits of modulus
	 */
	public int bitLength;
	/**
	 * p is a large prime.
	 */
	public BigInteger p;
	/**
	 * generator g.
	 */
	public BigInteger g;
	/**
	 * 'a' private key
	 */
	public BigInteger a;
	

	public ElgamalPrivateKey() {
		
	}

	public BigInteger Decryption(CipherTextElGamal c) {
		
		BigInteger biGamma = c.getGAMMA();
		BigInteger biDelta = c.getDELTA();
		
		return biGamma.modPow(p.subtract(BigInteger.ONE).subtract(a), p).multiply(biDelta).mod(p);
	}
	
	public SignatureElGamal Sign(BigInteger m) {
		
		BigInteger k;
		while(true){
			k = new BigInteger(bitLength, new SecureRandom());
			/* check whether k is good.*/
			if (k.gcd(p.subtract(BigInteger.ONE)).intValue() != 1) {
				System.out.println("k is not good. Choose k again.");
			}else{
				break;
			}
		}
		
		SignatureElGamal sign = new SignatureElGamal();
		sign.r = g.modPow(k, p);
		sign.s = m.subtract(a.multiply(sign.r)).multiply(k.modInverse(p.subtract(BigInteger.ONE))).mod(p.subtract(BigInteger.ONE));
		
		return sign;
	}
}
