package gr.kallipos.cryptography.chap04.testingDRBG;

import java.security.SecureRandom;
import java.security.Security;

import org.bouncycastle.crypto.EntropySourceProvider;
import org.bouncycastle.crypto.fips.FipsDRBG;
import org.bouncycastle.crypto.util.BasicEntropySourceProvider;
import org.bouncycastle.jcajce.provider.BouncyCastleFipsProvider;
import org.bouncycastle.util.Strings;
import org.bouncycastle.util.encoders.Hex;


public class TestDRBG {
	
	public static final byte[] Nonce = Strings.toByteArray("number only used once");
	public static final byte[] PersonalizationString = Strings.toByteArray("a constant personal marker");

	public static void main(String[] args) {
		Security.addProvider(new BouncyCastleFipsProvider());

        byte[] data = new byte[32];

        SecureRandom drgb1 = buildHASH_DRBG(false);

        drgb1.nextBytes(data);

        System.out.println("HASH_DRBG 1st random bytes:\t" + Hex.toHexString(data));

        drgb1.nextBytes(data);

        System.out.println("HASH_DRBG 2nd random bytes:\t" + Hex.toHexString(data));

        SecureRandom drgb2 = buildHMAC_DRBG(false);

        drgb2.nextBytes(data);

        System.out.println("HMAC_DRBG 1st random bytes:\t" + Hex.toHexString(data));

        drgb2.nextBytes(data);

        System.out.println("HMAC_DRBG 2nd random bytes:\t" + Hex.toHexString(data));
        
        SecureRandom drgb3 = buildCTR_DRBG(false);

        drgb3.nextBytes(data);

        System.out.println("CTR_DRBG 1st random bytes:\t" + Hex.toHexString(data));

        drgb3.nextBytes(data);

        System.out.println("CTR_DRBG 2nd random bytes:\t" + Hex.toHexString(data));
		
	}
	
    public static SecureRandom buildHASH_DRBG(boolean usePersonalizationString)
    {
        EntropySourceProvider entSource = new BasicEntropySourceProvider(new SecureRandom(), true);

        FipsDRBG.Builder drgbBldr = FipsDRBG.SHA512.fromEntropySource(entSource)
                                        .setSecurityStrength(256) //Παρεχόμενη ασφάλεια
                                        .setEntropyBitsRequired(256); //Εντροπία για αρχικοποίηση και ανανέωσης τυχαιότητας
        
        if(usePersonalizationString) drgbBldr.setPersonalizationString(PersonalizationString); //Συμβολοσειρά εξατομίκευσης

        return drgbBldr.build(Nonce, false);
    }

    public static SecureRandom buildHMAC_DRBG(boolean usePersonalizationString)
    {
        EntropySourceProvider entSource = new BasicEntropySourceProvider(new SecureRandom(), true);

        FipsDRBG.Builder drgbBldr = FipsDRBG.SHA512_HMAC.fromEntropySource(entSource)
                                        .setSecurityStrength(256) //Παρεχόμενη ασφάλεια
                                        .setEntropyBitsRequired(256); //Εντροπία για αρχικοποίηση και ανανέωσης τυχαιότητας
        
        if(usePersonalizationString) drgbBldr.setPersonalizationString(PersonalizationString); //Συμβολοσειρά εξατομίκευσης

        return drgbBldr.build(Nonce, false);
    }
    
    public static SecureRandom buildCTR_DRBG(boolean usePersonalizationString)
    {
        EntropySourceProvider entSource = new BasicEntropySourceProvider(new SecureRandom(), true);

        FipsDRBG.Builder drgbBldr = FipsDRBG.CTR_AES_256.fromEntropySource(entSource)
                                        .setSecurityStrength(256) //Παρεχόμενη ασφάλεια
                                        .setEntropyBitsRequired(256); //Εντροπία για αρχικοποίηση και ανανέωσης τυχαιότητας
        
        if(usePersonalizationString) drgbBldr.setPersonalizationString(PersonalizationString); //Συμβολοσειρά εξατομίκευσης

        return drgbBldr.build(Nonce, false);
    }

}
