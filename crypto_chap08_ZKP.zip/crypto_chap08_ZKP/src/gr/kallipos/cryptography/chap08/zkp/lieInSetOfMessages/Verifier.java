package gr.kallipos.cryptography.chap08.zkp.lieInSetOfMessages;

import java.math.BigInteger;
import java.security.SecureRandom;

import gr.kallipos.cryptography.chap08.asymmetric.paillier.PaillierPublicKey;


public class Verifier {
	
	private int bitLength;
	private PaillierPublicKey pubk;
	private int[] S;
	
	private BigInteger e;
	private BigInteger c;
	private BigInteger[] uj;

	public Verifier(int bitLength, PaillierPublicKey pubk, int[] S) {
		this.bitLength = bitLength;
		this.pubk = pubk;
		this.S = S;
	}
	
	public BigInteger getE_AndSetCUj(BigInteger c, BigInteger[] uj){
		this.c = c;
		this.uj = uj;
		this.e = getSecureRandowNumberInZn(this.bitLength,this.pubk.n);
		return e;
	}
	
	public boolean verifyAndSetVjEj(BigInteger[][] vjej){
		BigInteger ee = BigInteger.ZERO;
		for(int a = 0; a<vjej.length;a++){
			ee = ee.add(vjej[a][1]).mod(pubk.n);
		}
		if(!e.equals(ee)){
			return false;
		}
		
		for(int a = 0; a<vjej.length;a++){
			BigInteger v = uj[a].mod(pubk.nsquare).multiply((c.mod(pubk.nsquare).multiply(pubk.g.modPow(BigInteger.valueOf(S[a]), pubk.nsquare).modInverse(pubk.nsquare))).modPow(vjej[a][1], pubk.nsquare)).mod(pubk.nsquare);
			if(!vjej[a][0].modPow(pubk.n, pubk.nsquare).equals(v)){
				return false;
			}
		}

		return true;
	}
	
	public static BigInteger getSecureRandowNumberInZn(int bitLength, BigInteger n){
		BigInteger r;
		do {
			r = new BigInteger(bitLength, new SecureRandom());
		}
		while ((r.compareTo(BigInteger.ZERO) <= 0) || (r.compareTo(n) >= 0));

		return r;
	}

}
