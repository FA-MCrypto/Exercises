package gr.kallipos.cryptography.chap08.zkp.testing;

import gr.kallipos.cryptography.chap08.asymmetric.paillier.PaillierKeyPair;
import gr.kallipos.cryptography.chap08.zkp.lieInSetOfMessages.Prover;
import gr.kallipos.cryptography.chap08.zkp.lieInSetOfMessages.Verifier;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Arrays;

public class TestZKP {
	
	public static final int bitLength = 1024;
	public static final int[] S = {0, 2};
	public static final int m = 2;
	public static final int position = 1;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Publication: Drosatos, G., Tasidou, A., Efraimidis, P.S. (2012). Privacy-Preserving Television Audience Measurement Using
		//              Smart TVs. In: Gritzalis, D., Furnell, S., Theoharidou, M. (eds) Information Security and Privacy Research. SEC 
		//              2012. IFIP Advances in Information and Communication Technology, vol 376. Springer, Berlin, Heidelberg. 
		//              https://doi.org/10.1007/978-3-642-30436-1_19
		// Go to page 231, "Proof that an encrypted message lies in a given set of messages"
		
		PaillierKeyPair pkp = new PaillierKeyPair(bitLength);
		
		//[To ciphertext einai metaksu 0 'h 1!]
		System.out.println("Set of message: " + Arrays.toString(S));
		System.out.println("Selected message: " + m +" (in position "+position+" of set)");
		BigInteger randomNumber = new BigInteger(bitLength, new SecureRandom());
		BigInteger c = pkp.PublicKey.Encryption(BigInteger.valueOf(m),randomNumber);
		
		System.out.println("Ciphertext: " + c);
		
		Prover prov = new Prover(bitLength, pkp.PublicKey,S,position,randomNumber,c);
		Verifier ver = new Verifier(bitLength, pkp.PublicKey,S);
		
		System.out.println("Proof is valid: " + ver.verifyAndSetVjEj(prov.getVjEj_AndSetE(ver.getE_AndSetCUj(prov.c, prov.getUj()))));

	}

}
