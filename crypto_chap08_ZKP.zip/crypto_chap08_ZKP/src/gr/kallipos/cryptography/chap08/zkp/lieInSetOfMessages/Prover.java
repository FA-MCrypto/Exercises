package gr.kallipos.cryptography.chap08.zkp.lieInSetOfMessages;

import java.math.BigInteger;
import java.security.SecureRandom;

import gr.kallipos.cryptography.chap08.asymmetric.paillier.PaillierPublicKey;

public class Prover {

	private int bitLength;
	private PaillierPublicKey pubk;
	private int[] S;

	private int i;
	private BigInteger randomNumber;
	public BigInteger c; 	
	private BigInteger p;
	private BigInteger[] ej;
	private BigInteger[] vj;
	private BigInteger[] uj;
	private BigInteger e;

	public Prover(int bitLength, PaillierPublicKey pubk, int[] S, int i, BigInteger randomnumber, BigInteger c) {
		this.bitLength = bitLength;
		this.pubk = pubk;
		this.S = S;
		this.i = i;
		
		//this.randomNumber = new BigInteger(bitLength, new SecureRandom());
		//this.c = pubk.Encryption(BigInteger.valueOf(this.S[i]),this.randomNumber);
		this.randomNumber = randomnumber;
		this.c = c;
		this.p = getSecureRandowNumberInZn_Asterisk(this.bitLength, this.pubk.n);
		this.ej = new BigInteger[S.length];
		this.vj = new BigInteger[S.length];
		for(int a = 0; a<ej.length;a++){
			if(a == i){
				ej[a] = null;
			}else{
				ej[a] = getSecureRandowNumberInZn(this.bitLength, this.pubk.n);
			}
		}
		for(int a = 0; a<vj.length;a++){
			if(a == i){
				vj[a] = null;
			}else{
				vj[a] = getSecureRandowNumberInZn_Asterisk(this.bitLength, this.pubk.n);
			}
		}
		this.uj = new BigInteger[S.length];
	}

	public BigInteger[] getUj(){
		for(int a = 0; a<uj.length;a++){
			if(a == i){
				// p^N mod N^2
				uj[a] = p.modPow(pubk.n, pubk.nsquare);
			}else{
				// vj^N * (g^mj / c)^ej mod N^2
				uj[a] = vj[a].modPow(pubk.n, pubk.nsquare).multiply((pubk.g.modPow(BigInteger.valueOf(S[a]), pubk.nsquare).multiply(c.modInverse(pubk.nsquare))).modPow(ej[a], pubk.nsquare)).mod(pubk.nsquare);
			}
		}
		return this.uj;
	}

	public BigInteger[][] getVjEj_AndSetE(BigInteger e){
		this.e = e;
		BigInteger[][] vjej = new BigInteger[S.length][2];
		BigInteger sum_e = BigInteger.ZERO;
		for(int a = 0; a<ej.length;a++){
			if(a != i){
				vjej[a][1] = ej[a];
				vjej[a][0] = vj[a];
				sum_e = sum_e.add(ej[a]).mod(pubk.n);
			}
		}

		ej[i] = this.e.subtract(sum_e).mod(pubk.n);
		vjej[i][1] = ej[i];
		vj[i]= p.mod(pubk.n).multiply(randomNumber.modPow(ej[i], pubk.n)).multiply(pubk.g.modPow(this.e.subtract(sum_e).divide(pubk.n), pubk.n)).mod(pubk.n);
		vjej[i][0] = vj[i];
		return vjej;
	}

	public static BigInteger getSecureRandowNumberInZn_Asterisk(int bitLength, BigInteger n){	
		BigInteger r;
		do {
			r = new BigInteger(bitLength, new SecureRandom());
		}
		while ((r.compareTo(n) >= 0) || (r.gcd(n).intValue() != 1));

		return r;
	}

	public static BigInteger getSecureRandowNumberInZn(int bitLength, BigInteger n){
		BigInteger r;
		do {
			r = new BigInteger(bitLength, new SecureRandom());
		}
		while ((r.compareTo(BigInteger.ZERO) <= 0) || (r.compareTo(n) >= 0));

		return r;
	}

}
