package gr.kallipos.cryptography.chap04.testing;

import java.math.BigInteger;
import java.security.SecureRandom;
import gr.kallipos.cryptography.chap04.altAlgPRNGs.BlumBlumShub;

public class TestBBS {

	public static void main(String[] args) {
		// First use the internal, stock "true" random number
		// generator to get a "true random seed"
		SecureRandom r = new SecureRandom();
		System.out.println("Generating stock random seed");
		r.nextInt(); // need to do something for SR to be triggered.

		// Use this seed to generate a n-value for Blum-Blum-Shub
		// This value can be re-used if desired.
		System.out.println("Generating N ...");
		int bitsize = 512;
		BigInteger nval = BlumBlumShub.generateN(bitsize, r);
		System.out.println("N\t= "+nval);
		
		// now get a seed
		byte[] seed = new byte[bitsize/8];
		r.nextBytes(seed);
		System.out.println("Seed\t= "+new BigInteger(1,seed).mod(nval));

		// now create an instance of BlumBlumShub
		BlumBlumShub bbs = new BlumBlumShub(nval, seed);

		// and do something
		int numofbits = 16;
		System.out.println("\nGenerating 10 random "+numofbits+"-bit values:");
		for (int i = 0; i < 10; ++i) {
			int rnd = bbs.next(numofbits);
		    System.out.println(rnd+"\t-> "+String.format("%"+numofbits+"s", Integer.toBinaryString(rnd)).replaceAll(" ", "0"));
		}

		// OR
		// do everything almost automatically
		BlumBlumShub bbs2 = new BlumBlumShub(bitsize /*,+ optional random instance */);

		// reuse a nval (it's ok to do this)
		BlumBlumShub bbs3 = new BlumBlumShub(nval);

	}

}
