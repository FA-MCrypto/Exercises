package gr.kallipos.cryptography.chap04.testing;

import java.math.BigInteger;
import gr.kallipos.cryptography.chap04.altAlgPRNGs.Yarrow;

public class TestYarrow {

	public static void main(String[] args) {
        Yarrow yar = new Yarrow();
        
        System.out.println("Generating 10 random BigIntegers (160-bits size) with Yarrow:");
        for (int i = 1; i <= 10; i++) {
        	BigInteger rnd = new BigInteger(160,yar);
            System.out.println("Decimal Number: "+rnd+"\t-> Hex: "+rnd.toString(16).toUpperCase());
        }
	}

}
